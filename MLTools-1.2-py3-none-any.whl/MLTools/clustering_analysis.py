
"""
Utilities for clustering model selection with K-Means, Mean Shift, and DBSCAN.
"""

from __future__ import annotations

from itertools import product
from typing import Iterable, Optional, Sequence

import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
from scipy.spatial.distance import cdist
from sklearn.cluster import DBSCAN, KMeans, MeanShift
from sklearn.metrics import silhouette_score


def _as_2d_array(X, min_samples=2) -> np.ndarray:
    """
    Convert input data to a numeric 2D NumPy array.
    Parameters
    ----------
    X :
        Input data.
    min_samples : int
        Minimum number of rows required.
    """

    array = (X.to_numpy()
            if hasattr(X, "to_numpy")
            else np.asarray(X) )

    if array.ndim != 2:
        raise ValueError(
            "X must be a two-dimensional array."
        )

    if len(array) < min_samples:
        raise ValueError(
            f"X must contain at least "
            f"{min_samples} observation(s)."
        )

    return np.asarray(
        array,
        dtype=float
    )

def _safe_silhouette(
    X: np.ndarray,
    labels: np.ndarray,
    metric: str = "euclidean",
    ignore_noise: bool = False,
) -> float:
    """Return silhouette score or NaN when the score is undefined."""
    labels = np.asarray(labels)
    data = X

    if ignore_noise:
        mask = labels != -1
        data = data[mask]
        labels = labels[mask]

    unique_labels = np.unique(labels)

    if len(data) < 2:
        return np.nan

    if len(unique_labels) < 2:
        return np.nan

    if len(unique_labels) >= len(data):
        return np.nan

    try:
        return float(
            silhouette_score(
                data,
                labels,
                metric=metric,
            )
        )
    except ValueError:
        return np.nan


def mean_nearest_centroid_distance(
    X,
    centroids,
    metric: str = "euclidean",
) -> float:
    """
    Compute the mean distance from each observation to its nearest centroid.
    """
    data = _as_2d_array(X, min_samples=2)
    centers = _as_2d_array(centroids, min_samples=1)

    if data.shape[1] != centers.shape[1]:
        raise ValueError(
            "X and centroids must have the same number of features."
        )

    distances = cdist(
        data,
        centers,
        metric=metric,
    )

    return float(
        np.min(distances, axis=1).mean()
    )


def evaluate_kmeans_range(
    X_train,
    X_test=None,
    clusters: Iterable[int] = range(2, 11),
    metric: str = "euclidean",
    random_state: Optional[int] = 42,
    n_init: int | str = "auto",
) -> pd.DataFrame:
    """
    Evaluate K-Means for several candidate cluster counts.

    The model is fitted on X_train and evaluated on X_test when supplied.
    """
    train = _as_2d_array(X_train, min_samples=2)
    evaluation = train if X_test is None else _as_2d_array(X_test, min_samples=2)

    rows = []

    for n_clusters in clusters:
        model = KMeans(
            n_clusters=int(n_clusters),
            random_state=random_state,
            n_init=n_init,
        )
        model.fit(train)

        labels = model.predict(evaluation)

        rows.append({
            "n_clusters": int(n_clusters),
            "mean_nearest_centroid_distance": (
                mean_nearest_centroid_distance(
                    evaluation,
                    model.cluster_centers_,
                    metric=metric,
                )
            ),
            "inertia_train": float(model.inertia_),
            "silhouette": _safe_silhouette(
                evaluation,
                labels,
                metric=metric,
            ),
        })

    return pd.DataFrame(rows)


def evaluate_meanshift_bandwidths(
    X_train,
    X_test=None,
    bandwidths: Sequence[float] = (0.5, 1.0, 1.5, 2.0),
    metric: str = "euclidean",
    bin_seeding: bool = False,
    cluster_all: bool = True,
    max_iter: int = 300,
) -> pd.DataFrame:
    """
    Evaluate Mean Shift for several bandwidth values.

    The model is fitted on X_train and evaluated on X_test when supplied.
    """
    train = _as_2d_array(X_train, min_samples=2)
    evaluation = train if X_test is None else _as_2d_array(X_test, min_samples=2)

    rows = []

    for bandwidth in bandwidths:
        bandwidth = float(bandwidth)

        if bandwidth <= 0:
            raise ValueError("Bandwidth values must be positive.")

        model = MeanShift(
            bandwidth=bandwidth,
            bin_seeding=bin_seeding,
            cluster_all=cluster_all,
            max_iter=max_iter,
        )
        model.fit(train)

        labels = model.predict(evaluation)

        rows.append({
            "bandwidth": bandwidth,
            "n_clusters": int(len(np.unique(labels))),
            "mean_nearest_centroid_distance": (
                mean_nearest_centroid_distance(
                    evaluation,
                    model.cluster_centers_,
                    metric=metric,
                )
            ),
            "silhouette": _safe_silhouette(
                evaluation,
                labels,
                metric=metric,
            ),
        })

    return pd.DataFrame(rows)


def evaluate_dbscan_grid(
    X,
    eps_values: Sequence[float] = (0.2, 0.5, 0.8, 1.0),
    min_samples_values: Sequence[int] = (3, 5, 10),
    metric: str = "euclidean",
    ignore_noise_for_silhouette: bool = True,
) -> pd.DataFrame:
    """
    Evaluate DBSCAN over combinations of eps and min_samples.

    DBSCAN has no standard predict method, so fitting and evaluation use the
    same dataset.
    """
    data = _as_2d_array(X, min_samples=2)
    rows = []

    for eps, min_samples in product(
        eps_values,
        min_samples_values,
    ):
        eps = float(eps)
        min_samples = int(min_samples)

        if eps <= 0:
            raise ValueError("eps values must be positive.")

        if min_samples < 1:
            raise ValueError("min_samples values must be at least 1.")

        model = DBSCAN(
            eps=eps,
            min_samples=min_samples,
            metric=metric,
        )

        labels = model.fit_predict(data)

        cluster_labels = labels[labels != -1]
        n_clusters = len(np.unique(cluster_labels))
        n_noise = int(np.sum(labels == -1))

        rows.append({
            "eps": eps,
            "min_samples": min_samples,
            "n_clusters": int(n_clusters),
            "n_noise_points": n_noise,
            "noise_fraction": n_noise / len(data),
            "silhouette": _safe_silhouette(
                data,
                labels,
                metric=metric,
                ignore_noise=ignore_noise_for_silhouette,
            ),
        })

    return pd.DataFrame(rows)


def plot_clustering_metric(
    results: pd.DataFrame,
    x: str,
    y: str,
    group: Optional[str] = None,
    title: Optional[str] = None,
    x_label: Optional[str] = None,
    y_label: Optional[str] = None,
    ax=None,
):
    """
    Plot one metric from a clustering-analysis results DataFrame.
    """
    if ax is None:
        fig, ax = plt.subplots(figsize=(8, 5))
    else:
        fig = ax.figure

    if group is None:
        current = results.sort_values(x)
        ax.plot(
            current[x],
            current[y],
            marker="o",
        )
    else:
        for value, current in results.groupby(group):
            current = current.sort_values(x)
            ax.plot(
                current[x],
                current[y],
                marker="o",
                label=f"{group}={value}",
            )
        ax.legend()

    ax.set_xlabel(x if x_label is None else x_label)
    ax.set_ylabel(y if y_label is None else y_label)

    if title is not None:
        ax.set_title(title)

    return fig, ax


def generate_cluster_colors(labels, target_colors, default_color='lightgrey'):
    """
    Maps specific clusters to custom colors and groups the rest into a default color.
    
    Parameters:
    - labels: Array or list of cluster labels (e.g., meanshift_labels)
    - target_colors: Dictionary mapping {cluster_id: 'color_name'}
    - default_color: Color string for unmapped clusters
    
    Returns:
    - List of colors corresponding to each sample label
    """
    return [target_colors.get(label, default_color) for label in labels]


__all__ = [
    "mean_nearest_centroid_distance",
    "evaluate_kmeans_range",
    "evaluate_meanshift_bandwidths",
    "evaluate_dbscan_grid",
    "plot_clustering_metric",
    "generate_cluster_colors"
]
