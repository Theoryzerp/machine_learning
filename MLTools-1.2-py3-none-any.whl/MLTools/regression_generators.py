"""
Reusable synthetic regression-data generators.

Included generators
-------------------
- generate_nonlinear_regression
- generate_linear_regression
- generate_polynomial_regression
- generate_sine_regression
- generate_outlier_regression
- generate_piecewise_regression
- generate_heteroscedastic_regression
- plot_regression_dataset
"""

from __future__ import annotations

from typing import Callable, Optional, Sequence, Tuple

import matplotlib.pyplot as plt
import numpy as np
from matplotlib.axes import Axes
from matplotlib.figure import Figure


Array1D = np.ndarray
RegressionFunction = Callable[[np.ndarray], np.ndarray]


def _validate_regression_parameters(
    n_samples: int,
    x_range: Sequence[float],
    noise: float,
) -> Tuple[float, float]:
    """Validate common synthetic-regression parameters."""
    if n_samples < 2:
        raise ValueError("n_samples must be at least 2.")

    if len(x_range) != 2:
        raise ValueError("x_range must contain exactly two values.")

    x_min, x_max = float(x_range[0]), float(x_range[1])

    if x_min >= x_max:
        raise ValueError("x_range must satisfy x_range[0] < x_range[1].")

    if noise < 0:
        raise ValueError("noise cannot be negative.")

    return x_min, x_max


def _sample_sorted_x(
    n_samples: int,
    x_range: Sequence[float],
    random_state: Optional[int],
) -> Tuple[np.ndarray, np.random.Generator]:
    """Sample sorted one-dimensional inputs and return the RNG."""
    x_min, x_max = float(x_range[0]), float(x_range[1])
    rng = np.random.default_rng(random_state)

    X = np.sort(
        rng.uniform(
            low=x_min,
            high=x_max,
            size=n_samples,
        )
    ).reshape(-1, 1)

    return X, rng


def generate_nonlinear_regression(
    n_samples: int = 180,
    x_range: Sequence[float] = (-3.5, 3.5),
    function: str | RegressionFunction = "cubic",
    noise: float = 2.2,
    random_state: Optional[int] = 42,
) -> Tuple[np.ndarray, np.ndarray, np.ndarray]:
    """
    Generate a one-dimensional nonlinear regression dataset.

    Parameters
    ----------
    n_samples:
        Number of observations.
    x_range:
        Minimum and maximum x values.
    function:
        Name of a built-in function or a callable accepting a one-dimensional
        NumPy array.

        Supported names:
        - ``"linear"``
        - ``"quadratic"``
        - ``"cubic"``
        - ``"sin"``
        - ``"cos"``
        - ``"exp"``
    noise:
        Standard deviation of additive Gaussian noise.
    random_state:
        Random seed.

    Returns
    -------
    X:
        Feature matrix with shape ``(n_samples, 1)``.
    y:
        Noisy target values.
    y_true:
        Underlying noiseless target values.
    """
    _validate_regression_parameters(
        n_samples=n_samples,
        x_range=x_range,
        noise=noise,
    )

    X, rng = _sample_sorted_x(
        n_samples=n_samples,
        x_range=x_range,
        random_state=random_state,
    )

    x = X[:, 0]

    if callable(function):
        y_true = np.asarray(function(x), dtype=float)

        if y_true.shape != x.shape:
            raise ValueError(
                "A custom function must return one value per input observation."
            )
    else:
        functions = {
            "linear": lambda values: 2.0 * values + 1.0,
            "quadratic": lambda values: 0.8 * values**2 - 2.0 * values,
            "cubic": lambda values: 0.6 * values**3 - 2.2 * values,
            "sin": lambda values: 5.0 * np.sin(values),
            "cos": lambda values: 5.0 * np.cos(values),
            "exp": lambda values: np.exp(values / 2.0),
        }

        if function not in functions:
            supported = ", ".join(sorted(functions))
            raise ValueError(
                f"Unknown function '{function}'. Supported values: {supported}."
            )

        y_true = functions[function](x)

    y = y_true + rng.normal(
        loc=0.0,
        scale=noise,
        size=n_samples,
    )

    return X, y, y_true


def generate_linear_regression(
    n_samples: int = 150,
    x_range: Sequence[float] = (-5.0, 5.0),
    slope: float = 2.5,
    intercept: float = 1.0,
    noise: float = 2.0,
    random_state: Optional[int] = 42,
) -> Tuple[np.ndarray, np.ndarray, np.ndarray]:
    """
    Generate a simple linear-regression dataset.

    The underlying function is:

        y = intercept + slope * x
    """
    _validate_regression_parameters(
        n_samples=n_samples,
        x_range=x_range,
        noise=noise,
    )

    def linear_function(x: np.ndarray) -> np.ndarray:
        return intercept + slope * x

    return generate_nonlinear_regression(
        n_samples=n_samples,
        x_range=x_range,
        function=linear_function,
        noise=noise,
        random_state=random_state,
    )


def generate_polynomial_regression(
    n_samples: int = 180,
    x_range: Sequence[float] = (-3.5, 3.5),
    coefficients: Sequence[float] = (0.0, -2.2, 0.0, 0.6),
    noise: float = 2.2,
    random_state: Optional[int] = 42,
) -> Tuple[np.ndarray, np.ndarray, np.ndarray]:
    """
    Generate a polynomial-regression dataset.

    Parameters
    ----------
    coefficients:
        Polynomial coefficients in ascending power order.

        For example, ``(1, 2, 3)`` represents:

            y = 1 + 2x + 3x^2
    """
    _validate_regression_parameters(
        n_samples=n_samples,
        x_range=x_range,
        noise=noise,
    )

    coefficient_array = np.asarray(coefficients, dtype=float)

    if coefficient_array.ndim != 1 or coefficient_array.size == 0:
        raise ValueError(
            "coefficients must be a non-empty one-dimensional sequence."
        )

    def polynomial_function(x: np.ndarray) -> np.ndarray:
        y_true = np.zeros_like(x, dtype=float)

        for power, coefficient in enumerate(coefficient_array):
            y_true += coefficient * x**power

        return y_true

    return generate_nonlinear_regression(
        n_samples=n_samples,
        x_range=x_range,
        function=polynomial_function,
        noise=noise,
        random_state=random_state,
    )


def generate_sine_regression(
    n_samples: int = 180,
    x_range: Sequence[float] = (-2.0 * np.pi, 2.0 * np.pi),
    amplitude: float = 5.0,
    frequency: float = 1.0,
    phase: float = 0.0,
    vertical_shift: float = 0.0,
    noise: float = 0.8,
    random_state: Optional[int] = 42,
) -> Tuple[np.ndarray, np.ndarray, np.ndarray]:
    """
    Generate a sinusoidal regression dataset.

    The underlying function is:

        y = amplitude * sin(frequency * x + phase) + vertical_shift
    """
    _validate_regression_parameters(
        n_samples=n_samples,
        x_range=x_range,
        noise=noise,
    )

    def sine_function(x: np.ndarray) -> np.ndarray:
        return (
            amplitude * np.sin(frequency * x + phase)
            + vertical_shift
        )

    return generate_nonlinear_regression(
        n_samples=n_samples,
        x_range=x_range,
        function=sine_function,
        noise=noise,
        random_state=random_state,
    )


def generate_outlier_regression(
    n_samples: int = 160,
    x_range: Sequence[float] = (-5.0, 5.0),
    slope: float = 2.5,
    intercept: float = 1.0,
    noise: float = 1.2,
    outlier_fraction: float = 0.08,
    outlier_scale: float = 15.0,
    random_state: Optional[int] = 42,
) -> Tuple[np.ndarray, np.ndarray, np.ndarray, np.ndarray]:
    """
    Generate a linear dataset containing target outliers.

    Returns
    -------
    X, y, y_true, outlier_mask:
        ``outlier_mask`` is a Boolean array identifying injected outliers.
    """
    _validate_regression_parameters(
        n_samples=n_samples,
        x_range=x_range,
        noise=noise,
    )

    if not 0.0 <= outlier_fraction < 1.0:
        raise ValueError("outlier_fraction must be in the interval [0, 1).")

    if outlier_scale < 0:
        raise ValueError("outlier_scale cannot be negative.")

    X, y, y_true = generate_linear_regression(
        n_samples=n_samples,
        x_range=x_range,
        slope=slope,
        intercept=intercept,
        noise=noise,
        random_state=random_state,
    )

    rng = np.random.default_rng(random_state)
    n_outliers = int(round(n_samples * outlier_fraction))
    outlier_mask = np.zeros(n_samples, dtype=bool)

    if n_outliers > 0:
        outlier_indices = rng.choice(
            n_samples,
            size=n_outliers,
            replace=False,
        )

        outlier_mask[outlier_indices] = True

        signs = rng.choice(
            [-1.0, 1.0],
            size=n_outliers,
        )

        magnitudes = rng.uniform(
            low=0.5 * outlier_scale,
            high=outlier_scale,
            size=n_outliers,
        )

        y[outlier_indices] += signs * magnitudes

    return X, y, y_true, outlier_mask


def generate_piecewise_regression(
    n_samples: int = 180,
    x_range: Sequence[float] = (-5.0, 5.0),
    breakpoint: float = 0.0,
    left_slope: float = -1.5,
    right_slope: float = 2.5,
    intercept: float = 1.0,
    continuous: bool = True,
    noise: float = 1.0,
    random_state: Optional[int] = 42,
) -> Tuple[np.ndarray, np.ndarray, np.ndarray]:
    """
    Generate a piecewise-linear regression dataset.

    When ``continuous=True``, both linear segments meet at the breakpoint.
    """
    x_min, x_max = _validate_regression_parameters(
        n_samples=n_samples,
        x_range=x_range,
        noise=noise,
    )

    if not x_min < breakpoint < x_max:
        raise ValueError("breakpoint must lie inside x_range.")

    def piecewise_function(x: np.ndarray) -> np.ndarray:
        left_values = intercept + left_slope * x

        if continuous:
            value_at_breakpoint = (
                intercept + left_slope * breakpoint
            )
            right_intercept = (
                value_at_breakpoint
                - right_slope * breakpoint
            )
        else:
            right_intercept = intercept

        right_values = (
            right_intercept + right_slope * x
        )

        return np.where(
            x < breakpoint,
            left_values,
            right_values,
        )

    return generate_nonlinear_regression(
        n_samples=n_samples,
        x_range=x_range,
        function=piecewise_function,
        noise=noise,
        random_state=random_state,
    )


def generate_heteroscedastic_regression(
    n_samples: int = 180,
    x_range: Sequence[float] = (0.0, 8.0),
    slope: float = 2.0,
    intercept: float = 1.0,
    base_noise: float = 0.4,
    noise_growth: float = 0.35,
    random_state: Optional[int] = 42,
) -> Tuple[np.ndarray, np.ndarray, np.ndarray, np.ndarray]:
    """
    Generate a linear dataset with non-constant error variance.

    The standard deviation of the noise increases with x.

    Returns
    -------
    X, y, y_true, noise_std:
        ``noise_std`` contains the observation-specific noise scale.
    """
    x_min, x_max = _validate_regression_parameters(
        n_samples=n_samples,
        x_range=x_range,
        noise=base_noise,
    )

    if noise_growth < 0:
        raise ValueError("noise_growth cannot be negative.")

    X, rng = _sample_sorted_x(
        n_samples=n_samples,
        x_range=(x_min, x_max),
        random_state=random_state,
    )

    x = X[:, 0]
    y_true = intercept + slope * x

    normalized_position = (
        (x - x_min) / (x_max - x_min)
    )

    noise_std = (
        base_noise
        + noise_growth
        * normalized_position
        * (x_max - x_min)
    )

    y = y_true + rng.normal(
        loc=0.0,
        scale=noise_std,
        size=n_samples,
    )

    return X, y, y_true, noise_std


def plot_regression_dataset(
    X: np.ndarray,
    y: np.ndarray,
    y_true: Optional[np.ndarray] = None,
    title: str = "Regression Dataset",
    x_label: str = "x",
    y_label: str = "y",
    observed_label: str = "Observed data",
    true_label: str = "Underlying function",
    outlier_mask: Optional[np.ndarray] = None,
    ax: Optional[Axes] = None,
) -> Tuple[Figure, Axes]:
    """
    Plot a one-dimensional synthetic regression dataset.

    Parameters
    ----------
    X:
        Feature matrix with one column or a one-dimensional array.
    y:
        Observed targets.
    y_true:
        Optional noiseless target values.
    outlier_mask:
        Optional Boolean array. Outliers are highlighted with open markers.
    ax:
        Existing Matplotlib axes. A new figure is created when omitted.
    """
    X_array = np.asarray(X, dtype=float)

    if X_array.ndim == 2:
        if X_array.shape[1] != 1:
            raise ValueError(
                "X must contain exactly one feature for this plot."
            )
        x = X_array[:, 0]
    elif X_array.ndim == 1:
        x = X_array
    else:
        raise ValueError("X must be one- or two-dimensional.")

    y_array = np.asarray(y, dtype=float).ravel()

    if len(x) != len(y_array):
        raise ValueError("X and y must contain the same number of observations.")

    if y_true is not None:
        y_true_array = np.asarray(y_true, dtype=float).ravel()

        if len(y_true_array) != len(x):
            raise ValueError(
                "y_true must contain one value per observation."
            )
    else:
        y_true_array = None

    if outlier_mask is not None:
        mask = np.asarray(outlier_mask, dtype=bool).ravel()

        if len(mask) != len(x):
            raise ValueError(
                "outlier_mask must contain one value per observation."
            )
    else:
        mask = None

    if ax is None:
        fig, ax = plt.subplots(figsize=(9, 6))
    else:
        fig = ax.figure

    ax.scatter(
        x,
        y_array,
        alpha=0.7,
        label=observed_label,
    )

    if y_true_array is not None:
        order = np.argsort(x)

        ax.plot(
            x[order],
            y_true_array[order],
            linewidth=2,
            label=true_label,
        )

    if mask is not None and np.any(mask):
        ax.scatter(
            x[mask],
            y_array[mask],
            s=100,
            facecolors="none",
            edgecolors="black",
            linewidths=1.5,
            label="Outliers",
        )

    ax.set_xlabel(x_label)
    ax.set_ylabel(y_label)
    ax.set_title(title)
    ax.legend()

    return fig, ax


__all__ = [
    "generate_nonlinear_regression",
    "generate_linear_regression",
    "generate_polynomial_regression",
    "generate_sine_regression",
    "generate_outlier_regression",
    "generate_piecewise_regression",
    "generate_heteroscedastic_regression",
    "plot_regression_dataset",
]
