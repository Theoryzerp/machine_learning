"""
Reusable utilities for machine-learning notebooks.

This module provides functions for:

- Distance calculations
- Synthetic isotropic dataset generation
- Radial feature mappings
- Decision-boundary visualization
- Two-dimensional and three-dimensional plotting
- Linear SVM separating-plane visualization

Typical usage
-------------
Place this file in the same directory as the notebook:

    from MLTools import (
        euclidean_distance,
        generate_isotropic_circles,
        radial_map_2d_to_3d,
        plot_boundary,
    )
"""

from __future__ import annotations

from typing import Any, Optional, Sequence, Tuple

import matplotlib.pyplot as plt
import numpy as np
from matplotlib.axes import Axes
from matplotlib.figure import Figure
from sklearn.datasets import make_blobs, make_circles

ArrayLike = Any


def _to_numpy_2d(X: ArrayLike) -> np.ndarray:
    if hasattr(X, "to_numpy"):
        array = X.to_numpy()
    else:
        array = np.asarray(X)
    if array.ndim != 2:
        raise ValueError("X must be a two-dimensional feature matrix.")
    return array


def _to_numpy_1d(y: ArrayLike) -> np.ndarray:
    if hasattr(y, "to_numpy"):
        array = y.to_numpy()
    else:
        array = np.asarray(y)
    return np.ravel(array)


def euclidean_distance(point_a: ArrayLike, point_b: ArrayLike) -> float:
    """Calculate the Euclidean distance between two one-dimensional points."""
    a = np.asarray(point_a, dtype=float)
    b = np.asarray(point_b, dtype=float)
    if a.shape != b.shape:
        raise ValueError("Both points must have the same shape.")
    if a.ndim != 1:
        raise ValueError("Each point must be one-dimensional.")
    return float(np.linalg.norm(a - b))


def pairwise_euclidean_distances(query_point: ArrayLike, observations: ArrayLike) -> np.ndarray:
    """Calculate distances from one query point to many observations."""
    query = np.asarray(query_point, dtype=float)
    data = _to_numpy_2d(observations).astype(float)
    if query.ndim != 1:
        raise ValueError("query_point must be one-dimensional.")
    if data.shape[1] != query.shape[0]:
        raise ValueError("The query point and observations must have the same number of features.")
    return np.linalg.norm(data - query, axis=1)


def generate_isotropic_circles(
    n_samples: int = 500,
    factor: float = 0.42,
    noise: float = 0.08,
    random_state: Optional[int] = 42,
    center: Sequence[float] = (0.0, 0.0),
    scale: float = 1.0,
) -> Tuple[np.ndarray, np.ndarray]:
    """Generate approximately isotropic concentric circles."""
    if n_samples < 2:
        raise ValueError("n_samples must be at least 2.")
    if not 0 < factor < 1:
        raise ValueError("factor must be between 0 and 1.")
    if noise < 0:
        raise ValueError("noise cannot be negative.")
    center_array = np.asarray(center, dtype=float)
    if center_array.shape != (2,):
        raise ValueError("center must contain exactly two coordinates.")
    X, y = make_circles(
        n_samples=n_samples,
        factor=factor,
        noise=noise,
        random_state=random_state,
    )
    X = X * float(scale) + center_array
    return X, y


def generate_isotropic_blobs(
    n_samples: int = 400,
    centers: int | ArrayLike = 3,
    cluster_std: float | Sequence[float] = 1.0,
    random_state: Optional[int] = 42,
    center_box: Tuple[float, float] = (-6.0, 6.0),
) -> Tuple[np.ndarray, np.ndarray]:
    """Generate isotropic Gaussian clusters for classification examples."""
    X, y = make_blobs(
        n_samples=n_samples,
        centers=centers,
        n_features=2,
        cluster_std=cluster_std,
        center_box=center_box,
        random_state=random_state,
    )
    return X, y


def generate_radial_bands(
    n_samples: int = 500,
    radii: Sequence[float] = (0.5, 1.25),
    radial_noise: float = 0.08,
    random_state: Optional[int] = 42,
) -> Tuple[np.ndarray, np.ndarray]:
    """Generate custom isotropic circular bands, one class per radius."""
    radii_array = np.asarray(radii, dtype=float)
    if radii_array.ndim != 1 or len(radii_array) < 2:
        raise ValueError("radii must contain at least two positive values.")
    if np.any(radii_array <= 0):
        raise ValueError("All radii must be positive.")
    if radial_noise < 0:
        raise ValueError("radial_noise cannot be negative.")

    rng = np.random.default_rng(random_state)
    y = np.resize(np.arange(len(radii_array)), n_samples)
    rng.shuffle(y)
    angles = rng.uniform(0.0, 2.0 * np.pi, size=n_samples)
    noisy_radii = radii_array[y] + rng.normal(0.0, radial_noise, size=n_samples)
    X = np.column_stack((
        noisy_radii * np.cos(angles),
        noisy_radii * np.sin(angles),
    ))
    return X, y


def radial_feature(X: ArrayLike, power: float = 2.0) -> np.ndarray:
    """Calculate a radial feature from the first two columns of X."""
    data = _to_numpy_2d(X).astype(float)
    if data.shape[1] < 2:
        raise ValueError("X must contain at least two features.")
    if power <= 0:
        raise ValueError("power must be positive.")
    return np.sum(np.abs(data[:, :2]) ** power, axis=1)


def radial_map_2d_to_3d(X: ArrayLike, power: float = 2.0) -> np.ndarray:
    """Map [x1, x2] to [x1, x2, |x1|**power + |x2|**power]."""
    data = _to_numpy_2d(X).astype(float)
    if data.shape[1] < 2:
        raise ValueError("X must contain at least two features.")
    coords = data[:, :2]
    z = radial_feature(coords, power=power)
    return np.column_stack((coords, z))


def make_prediction_grid(
    X: ArrayLike,
    padding: float = 0.5,
    resolution: int = 400,
) -> Tuple[np.ndarray, np.ndarray, np.ndarray]:
    """Create a dense two-dimensional grid for decision-boundary plots."""
    data = _to_numpy_2d(X).astype(float)
    if data.shape[1] != 2:
        raise ValueError("Decision-boundary grids require exactly two features.")
    if resolution < 20:
        raise ValueError("resolution must be at least 20.")
    x1_min, x1_max = data[:, 0].min() - padding, data[:, 0].max() + padding
    x2_min, x2_max = data[:, 1].min() - padding, data[:, 1].max() + padding
    xx, yy = np.meshgrid(
        np.linspace(x1_min, x1_max, resolution),
        np.linspace(x2_min, x2_max, resolution),
    )
    grid = np.column_stack((xx.ravel(), yy.ravel()))
    return xx, yy, grid


def plot_2d_dataset(
    X: ArrayLike,
    y: ArrayLike,
    title: str = "Two-Dimensional Dataset",
    feature_names: Sequence[str] = ("x1", "x2"),
    class_names: Optional[Sequence[str]] = None,
    equal_aspect: bool = False,
    ax: Optional[Axes] = None,
) -> Tuple[Figure, Axes]:
    """Plot a labeled two-dimensional dataset."""
    data = _to_numpy_2d(X)
    labels = _to_numpy_1d(y)
    if data.shape[1] != 2:
        raise ValueError("X must contain exactly two features.")
    if len(data) != len(labels):
        raise ValueError("X and y must contain the same number of observations.")
    if ax is None:
        fig, ax = plt.subplots(figsize=(8, 6))
    else:
        fig = ax.figure
    classes = np.unique(labels)
    for position, class_value in enumerate(classes):
        mask = labels == class_value
        label = class_names[position] if class_names is not None else f"Class {class_value}"
        ax.scatter(data[mask, 0], data[mask, 1], label=label, edgecolors="black", alpha=0.75)
    ax.set_xlabel(feature_names[0])
    ax.set_ylabel(feature_names[1])
    ax.set_title(title)
    ax.legend()
    if equal_aspect:
        ax.set_aspect("equal", adjustable="box")
    return fig, ax


def _extract_support_vectors_original_space(model: Any) -> Optional[np.ndarray]:
    if hasattr(model, "support_vectors_"):
        return np.asarray(model.support_vectors_)
    if not hasattr(model, "named_steps"):
        return None
    svm_step = next((s for s in model.named_steps.values() if hasattr(s, "support_vectors_")), None)
    if svm_step is None:
        return None
    vectors = np.asarray(svm_step.support_vectors_)
    scaler_step = next((s for s in model.named_steps.values() if hasattr(s, "inverse_transform") and hasattr(s, "scale_")), None)
    if scaler_step is not None:
        vectors = scaler_step.inverse_transform(vectors)
    return vectors


def plot_decision_boundaries(
    model: Any,
    X: ArrayLike,
    y: ArrayLike,
    title: str = "Decision Boundary",
    feature_names: Sequence[str] = ("x1", "x2"),
    class_names: Optional[Sequence[str]] = None,
    padding: float = 0.5,
    resolution: int = 400,
    show_support_vectors: bool = False,
    ax: Optional[Axes] = None,
) -> Tuple[Figure, Axes]:
    """Plot 2D decision regions for a fitted classifier or pipeline."""
    data = _to_numpy_2d(X).astype(float)
    labels = _to_numpy_1d(y)
    if data.shape[1] != 2:
        raise ValueError("plot_boundary requires exactly two features.")

    xx, yy, grid = make_prediction_grid(data, padding=padding, resolution=resolution)
    if hasattr(X, "columns"):
        import pandas as pd
        prediction_input = pd.DataFrame(grid, columns=X.columns)
    else:
        prediction_input = grid

    zz = np.asarray(model.predict(prediction_input)).reshape(xx.shape)

    if ax is None:
        fig, ax = plt.subplots(figsize=(8, 6))
    else:
        fig = ax.figure

    ax.contourf(xx, yy, zz, alpha=0.25, cmap="Paired")
    classes = np.unique(labels)
    for position, class_value in enumerate(classes):
        mask = labels == class_value
        label = class_names[position] if class_names is not None else f"Class {class_value}"
        ax.scatter(data[mask, 0], data[mask, 1], label=label, edgecolors="black", alpha=0.75, cmap="Paired")

    if show_support_vectors:
        sv = _extract_support_vectors_original_space(model)
        if sv is not None:
            ax.scatter(sv[:, 0], sv[:, 1], s=180, facecolors="none", edgecolors="black", linewidths=2, label="Support vectors", cmap="Paired")

    ax.set_xlabel(feature_names[0])
    ax.set_ylabel(feature_names[1])
    ax.set_title(title)
    ax.legend()
    return fig, ax


def plot_radial_mapping_3d(
    X: ArrayLike,
    y: ArrayLike,
    power: float = 2.0,
    title: str = "Radial Mapping into 3D",
    feature_names: Sequence[str] = ("x1", "x2", "radial feature"),
    class_names: Optional[Sequence[str]] = None,
    ax: Optional[Axes] = None,
) -> Tuple[Figure, Axes]:
    """Map 2D observations to 3D and display the transformed data."""
    mapped = radial_map_2d_to_3d(X, power=power)
    labels = _to_numpy_1d(y)
    if ax is None:
        fig = plt.figure(figsize=(10, 8))
        ax = fig.add_subplot(111, projection="3d")
    else:
        fig = ax.figure
    classes = np.unique(labels)
    for position, class_value in enumerate(classes):
        mask = labels == class_value
        label = class_names[position] if class_names is not None else f"Class {class_value}"
        ax.scatter(mapped[mask, 0], mapped[mask, 1], mapped[mask, 2], label=label, alpha=0.7)
    ax.set_xlabel(feature_names[0])
    ax.set_ylabel(feature_names[1])
    ax.set_zlabel(feature_names[2])
    ax.set_title(title)
    ax.legend()
    return fig, ax


def original_linear_plane_parameters(
    pipeline: Any,
    scaler_step_name: str = "scaler",
    estimator_step_name: str = "svm",
) -> Tuple[np.ndarray, float]:
    """Convert a scaled linear SVM hyperplane to original feature coordinates."""
    if not hasattr(pipeline, "named_steps"):
        raise TypeError("pipeline must be a fitted scikit-learn Pipeline.")
    scaler = pipeline.named_steps[scaler_step_name]
    estimator = pipeline.named_steps[estimator_step_name]
    if not hasattr(estimator, "coef_"):
        raise ValueError("The estimator must expose coef_; use a linear SVM.")
    w_scaled = np.asarray(estimator.coef_[0], dtype=float)
    b_scaled = float(estimator.intercept_[0])
    w_original = w_scaled / scaler.scale_
    b_original = b_scaled - np.sum(w_scaled * scaler.mean_ / scaler.scale_)
    return w_original, float(b_original)


def plot_linear_plane_3d(
    model: Any,
    X_3d: ArrayLike,
    y: ArrayLike,
    title: str = "Linear Separating Plane in 3D",
    feature_names: Sequence[str] = ("x1", "x2", "z"),
    class_names: Optional[Sequence[str]] = None,
    scaler_step_name: str = "scaler",
    estimator_step_name: str = "svm",
    grid_resolution: int = 30,
    ax: Optional[Axes] = None,
) -> Tuple[Figure, Axes]:
    """Plot 3D data and the separating plane of a fitted linear SVM pipeline."""
    data = _to_numpy_2d(X_3d).astype(float)
    labels = _to_numpy_1d(y)
    if data.shape[1] != 3:
        raise ValueError("X_3d must contain exactly three features.")

    w, b = original_linear_plane_parameters(model, scaler_step_name, estimator_step_name)
    if np.isclose(w[2], 0.0):
        raise ValueError("The plane cannot be solved for z because w[2] is zero.")

    gx, gy = np.meshgrid(
        np.linspace(data[:, 0].min(), data[:, 0].max(), grid_resolution),
        np.linspace(data[:, 1].min(), data[:, 1].max(), grid_resolution),
    )
    gz = -(w[0] * gx + w[1] * gy + b) / w[2]

    if ax is None:
        fig = plt.figure(figsize=(11, 8))
        ax = fig.add_subplot(111, projection="3d")
    else:
        fig = ax.figure

    classes = np.unique(labels)
    for position, class_value in enumerate(classes):
        mask = labels == class_value
        label = class_names[position] if class_names is not None else f"Class {class_value}"
        ax.scatter(data[mask, 0], data[mask, 1], data[mask, 2], label=label, alpha=0.65)

    ax.plot_surface(gx, gy, gz, alpha=0.25)
    ax.set_xlabel(feature_names[0])
    ax.set_ylabel(feature_names[1])
    ax.set_zlabel(feature_names[2])
    ax.set_title(title)
    ax.legend()
    return fig, ax


__all__ = [
    "euclidean_distance",
    "pairwise_euclidean_distances",
    "generate_isotropic_circles",
    "generate_isotropic_blobs",
    "generate_radial_bands",
    "radial_feature",
    "radial_map_2d_to_3d",
    "make_prediction_grid",
    "plot_2d_dataset",
    "plot_decision_boundaries",
    "plot_radial_mapping_3d",
    "original_linear_plane_parameters",
    "plot_linear_plane_3d"
]
