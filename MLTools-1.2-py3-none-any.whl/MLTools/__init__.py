
# ============================================================
# Package metadata
# ============================================================

__title__ = "MLTools"
__description__ = (
    "Reusable utility functions for machine-learning notebooks, "
    "including classification utils, synthetic data generation, "
    "decision-boundary visualization, regression tools and clustering analysis"
)

__version__ = "1.2.0"

__author__ = "Rubén D. Fonnegra, Ph.D."
__author_email__ = "ruben.fonnegra@pascualbravo.edu.co"

__license__ = "MIT"
__copyright__ = "Copyright (c) 2026 - Rubén D. Fonnegra"

__status__ = "Development"

__python_requires__ = ">=3.10"

__dependencies__ = (
    "numpy",
    "matplotlib",
    "scikit-learn",
)

from .classification_generators import *
from .regression_generators import *
from .clustering_analysis import *